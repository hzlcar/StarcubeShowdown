/* 
 * Connor Caruthers
 * 2365827
 * ccaruthers@chapman.edu
 * CPSC-340-01
 * Starcube Showdown
 * 
 * This script was supposed to have more functionality but is now just used to identify the Cannon
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannon : MonoBehaviour
{
    public MeshRenderer cannon;
    public MeshRenderer cannonHole;
}
